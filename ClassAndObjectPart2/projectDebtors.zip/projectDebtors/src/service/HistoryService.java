package service;

import model.History;

import java.util.UUID;

public class HistoryService {
    public History[] histories = new History[100];
    public History printHistory(UUID historyId) {
        for (History history : histories)  {
            if (history != null) {
                return history;
            }
        }
        return null;
    }

}
