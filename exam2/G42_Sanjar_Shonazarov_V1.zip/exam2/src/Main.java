import model.Company;
import model.Manager;
import service.CompanyService;
import service.ManagerService;
import java.util.Scanner;

public class Main {
    static Scanner scannerStr = new Scanner(System.in);
    static Scanner scannerInt = new Scanner(System.in);
    public static void main(String[] args) {
        int stepCode = 10;
        CompanyService companyService = new CompanyService();
        ManagerService managerService = new ManagerService();
        while (true) {
            System.out.println("1. register 2. login 0. exit");
            stepCode = scannerInt.nextInt();
            if (stepCode == 1) {
                Company company = getCompanyFromConsole();
                if (companyService.addCompany(company)) {
                    System.out.println("successfully");
                } else {
                    System.out.println("error");
                }
            } else if (stepCode == 2) {
                System.out.println("enter name: ");
                String name = scannerStr.nextLine();
                System.out.println("enter password: ");
                String password = scannerStr.nextLine();
                Company currentCompany = companyService.login(name, password);
                if (currentCompany != null) {
                    int command = 10;
                    while (command != 0) {
                        System.out.println("1. add manager 2. delete manager 0. exit");
                        command = scannerInt.nextInt();
                        switch (command) {
                            case 1 -> {
                                Manager manager = getManagerFromConsole();
                            }
                            case 2 -> {

                            }
                        }
                    }
                }
            }
        }
    }

    private static Manager getManagerFromConsole() {
        Manager manager = new Manager();
        System.out.println("enter name: ");
        manager.managerName = scannerStr.nextLine();
        return manager;
    }


    private static Company getCompanyFromConsole() {
        Company company = new Company();
        System.out.println("Enter company name: ");
        company.name = scannerStr.nextLine();
        return company;
    }
}