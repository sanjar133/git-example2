package service;

import model.Company;
import model.Manager;

import java.util.UUID;

public class CompanyService {
    private final Company[] companies = new Company[100];
    private int companyIndex = 0;
    public boolean addCompany(Company company) {
        if (!hasCompany(company.name, company.password)) {
            companies[companyIndex++] = company;
            return true;
        }
        return false;
    }
    private boolean hasCompany(String name, String password) {
        for (Company company : companies) {
            if (company != null && company.name.equals(name) && company.password.equals(password)) {
                return true;
            }
        }
        return false;
    }
    public Company[] getCompanies() {
        return companies;
    }
    public Company getCompanyById(UUID id) {
        for (Company company : companies) {
            if (company != null && company.id.equals(id)) {
                return company;
            }
        }
        return null;
    }
    public Company login(String name, String password) {
        for (Company company : companies) {
            if (company != null && company.name.equals(name) && company.password.equals(password)) {
                return company;
            }
        }
        return null;
    }
}
