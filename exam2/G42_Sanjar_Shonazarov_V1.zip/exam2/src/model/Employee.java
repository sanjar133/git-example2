package model;

import java.util.UUID;

public class Employee {
    private String employeeName;
    public UUID managerId;

    public Employee(String employeeName, UUID managerId) {
        this.employeeName = employeeName;
        this.managerId = managerId;
    }

    public UUID getManagerId() {
        return managerId;
    }

    public void setManagerId(UUID managerId) {
        this.managerId = managerId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }


}
