package model;

import java.util.UUID;

public class Company {
    public UUID id;
    public String name;
    public String password;

    public Company() {
        this.id = UUID.randomUUID();
    }
    public Company(String name, String password) {
        this();
        this.name = name;
        this.password = password;
    }
}
