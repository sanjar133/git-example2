package service;

public class EmployeeService {
}
