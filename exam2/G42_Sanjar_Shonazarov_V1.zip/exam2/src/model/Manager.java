package model;

import java.util.UUID;

public class Manager {
    public String managerName;
    public UUID companyId;


}
