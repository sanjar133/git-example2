package model;

import java.util.UUID;

public class History {
    public UUID id;
    public History() {
        this.id = UUID.randomUUID();
    }

}
