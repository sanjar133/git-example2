package service;

import model.Company;
import model.Manager;

import java.util.UUID;

public class ManagerService {
    private Manager[] managers = new Manager[1000];

    public Manager getManagersByName(UUID companyId, String name) {
        for (Manager manager : managers) {
            if (manager != null &&
                    manager.managerName.equals(name) && manager.companyId.equals(companyId)) {
                return manager;
            }
        }
        return null;
    }
}